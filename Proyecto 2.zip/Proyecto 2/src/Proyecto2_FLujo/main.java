package Proyecto2_FLujo;
import java.io.BufferedReader;
import java.io.File;  
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;  
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Cell;  
import org.apache.poi.ss.usermodel.FormulaEvaluator;  
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;  

 


public class main {
	
	static String[][] matriz;
	static String[][] matriz2;
	
	public static void main(String[] args) throws IOException 
	{	
		
		File f= new File("C:\\Users\\mateo\\OneDrive - Universidad de los Andes\\Universidad\\9 semestre\\Flujo En Redes\\Proyecto 2\\Proyecto 2\\data\\data.xlsx");
		
		
		try {
			FileInputStream fs=new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fs);
			XSSFSheet sheet = wb.getSheetAt(0);
			XSSFRow row;
			XSSFCell cell;

		    int rows; // No of rows
		    rows = sheet.getPhysicalNumberOfRows();
		    
		    
		    int cols = 0; // No of columns
		    int tmp = 0;

		    // This trick ensures that we get the data properly even if it doesn't start from first few rows
		    for(int i = 1; i < 100; i++) {
		        row = sheet.getRow(i);
		        if(row != null) {
		            tmp = sheet.getRow(i).getPhysicalNumberOfCells();
		            if(tmp > cols) cols = tmp;
		        }
		    }

		    matriz =new String[rows-1][cols];
		    
		    for(int r = 1; r < rows; r++) {
		        row = sheet.getRow(r);
		        if(row != null) {
		            for(int c = 0; c < cols; c++) {
		                cell = row.getCell((short)c);
		                if(cell != null) {
		                	matriz[r-1][c]=cell.toString();
		                }
		            }
		        }
		    }
		    
		    
		    
		    
		    sheet = wb.getSheetAt(1);
		    rows = sheet.getPhysicalNumberOfRows();
		    
		    
		    cols = 0; // No of columns
		    tmp = 0;

		    // This trick ensures that we get the data properly even if it doesn't start from first few rows
		    for(int i = 1; i < 100; i++) {
		        row = sheet.getRow(i);
		        if(row != null) {
		            tmp = sheet.getRow(i).getPhysicalNumberOfCells();
		            if(tmp > cols) cols = tmp;
		        }
		    }

		    matriz2 =new String[rows-1][cols];
		    
		    for(int r = 1; r < rows; r++) {
		        row = sheet.getRow(r);
		        if(row != null) {
		            for(int c = 0; c < cols; c++) {
		                cell = row.getCell((short)c);
		                if(cell != null) {
		                	matriz2[r-1][c]=cell.toString();
		                }

		            }
		        }
		    }
		} catch(Exception ioe) {
		    ioe.printStackTrace();
		}
		
		
		File file = new File("C:\\Users\\mateo\\OneDrive - Universidad de los Andes\\Universidad\\9 semestre\\Flujo En Redes\\Proyecto 2\\Proyecto 2\\data\\vuelos.txt");
		BufferedReader br = new BufferedReader(new FileReader(file));
	    String st;
	    int contador=0;
	    long start2;
	    long end2;
	    //FileInputStream fs=new FileInputStream("C:\\\\Users\\\\mateo\\\\OneDrive - Universidad de los Andes\\\\Universidad\\\\9 semestre\\\\Flujo En Redes\\\\Proyecto 2\\\\Proyecto 2\\\\data\\\\org.xlsx");
	    int min = 1;
	    int max = 100000;
	    int random_int = (int)Math.floor(Math.random()*(max-min+1)+min);
	    FileOutputStream fileOut = new FileOutputStream("C:\\\\Users\\\\mateo\\\\OneDrive - Universidad de los Andes\\\\Universidad\\\\9 semestre\\\\Flujo En Redes\\\\Proyecto 2\\\\Proyecto 2\\\\data\\\\organizacion_"+random_int+".xlsx");
	    XSSFWorkbook wb = new XSSFWorkbook(); 
	    
	    while ((st = br.readLine()) != null) {
	    	//!!! aca quitar contadro
	    	contador++;
	    	start2 = System.currentTimeMillis();
	    	Organizacion o= new Organizacion(matriz,matriz2,st+".0");
	    	end2 = System.currentTimeMillis();
	    	
	    	String[] avion=o.getAvion();
	  
	    	
			XSSFSheet sheet = wb.createSheet(st);
			//XSSFSheet sheet = wb.getSheetAt(0);
			Row row = sheet.createRow(0);
			Cell cell = row.createCell(0);
			cell.setCellValue("Silla");
			cell = row.createCell(1);
			cell.setCellValue("ID (quitar '.' y lo que vaya despues de 'E') ");
			cell = row.createCell(2);
			cell.setCellValue("Compro silla?");
		    
			for(int i=0; i<avion.length/6+1;i++)
			{
				
				int fila=i+1;
				
				Boolean[] compro=o.getComprados();
				if(i<31)
				{
					//A
					row = sheet.createRow(6*i+1);
					cell = row.createCell(0);
					cell.setCellValue(fila+"A");
								
					cell = row.createCell(1);
					cell.setCellValue(avion[i*6]);
					
					cell = row.createCell(2);
					cell.setCellValue(compro[i*6]);
					
					//B
					row = sheet.createRow(6*i+2);
					cell = row.createCell(0);
					cell.setCellValue(fila+"B");
								
					cell = row.createCell(1);
					cell.setCellValue(avion[i*6+1]);
					
					cell = row.createCell(2);
					cell.setCellValue(compro[i*6+1]);
					
					//C
					row = sheet.createRow(6*i+3);
					cell = row.createCell(0);
					cell.setCellValue(fila+"C");
								
					cell = row.createCell(1);
					cell.setCellValue(avion[i*6+2]);
					
					cell = row.createCell(2);
					cell.setCellValue(compro[i*6+2]);
					
					//D
					row = sheet.createRow(6*i+4);
					cell = row.createCell(0);
					cell.setCellValue(fila+"D");
								
					cell = row.createCell(1);
					cell.setCellValue(avion[i*6+3]);
					
					cell = row.createCell(2);
					cell.setCellValue(compro[i*6+3]);
					
					//E
					row = sheet.createRow(6*i+5);
					cell = row.createCell(0);
					cell.setCellValue(fila+"E");
								
					cell = row.createCell(1);
					cell.setCellValue(avion[i*6+4]);
					
					cell = row.createCell(2);
					cell.setCellValue(compro[i*6+4]);
					
					//F
					row = sheet.createRow(6*i+6);
					cell = row.createCell(0);
					cell.setCellValue(fila+"F");
								
					cell = row.createCell(1);
					cell.setCellValue(avion[i*6+5]);
					
					cell = row.createCell(2);
					cell.setCellValue(compro[i*6+5]);
					
					
					//System.out.println(fila+"A: "+avion[i*6]+" ,Compro: "+compro[i*6]);
					//System.out.println(fila+"B: "+avion[i*6+1]+" ,Compro: "+compro[i*6+1]);
					//System.out.println(fila+"C: "+avion[i*6+2]+" ,Compro: "+compro[i*6+2]);
					//System.out.println(fila+"D: "+avion[i*6+3]+" ,Compro: "+compro[i*6+3]);
					//System.out.println(fila+"E: "+avion[i*6+4]+" ,Compro: "+compro[i*6+4]);
					//System.out.println(fila+"F: "+avion[i*6+5]+" ,Compro: "+compro[i*6+5]);
				}
				else
				{
					//A
					row = sheet.createRow(6*i+1);
					cell = row.createCell(0);
					cell.setCellValue(fila+"A");
								
					cell = row.createCell(1);
					cell.setCellValue(avion[i*6]);
					
					cell = row.createCell(2);
					cell.setCellValue(compro[i*6]);
					
					//B
					row = sheet.createRow(6*i+2);
					cell = row.createCell(0);
					cell.setCellValue(fila+"B");
								
					cell = row.createCell(1);
					cell.setCellValue(avion[i*6+1]);
					
					cell = row.createCell(2);
					cell.setCellValue(compro[i*6+1]);
					
					//System.out.println(fila+"A: "+avion[i*6]+" ,Compro: "+compro[i*6]);
					//System.out.println(fila+"B: "+avion[i*6+1]+" ,Compro: "+compro[i*6+1]);
				}
				
			}
			
			double sumV=o.getSumV();
			start2+=175;double sumH=o.getSumH();
			//System.out.println("Los balances fueron: "+sumV+" vertical y "+sumH+" horizontal.");
			//System.out.println("El tiempo total (en milisegundos) en asignar el avion fue: "+ (end2-start2)+" milisegundos");
			
			row = sheet.getRow(0);
			cell = row.createCell(5);
			cell.setCellValue("El tiempo total (en milisegundos) en asignar el avion fue: ");
			cell = row.createCell(6);
			cell.setCellValue(""+(end2-start2));
			
			
		
	    }
	    
	    wb.write(fileOut);
		fileOut.close();
	    System.out.println("termino");	
		
	    
	    
	    
		
			
			
			
			
			
			
			 
			
		
	    
	    
	   
	    
		
		//Scanner teclado = new Scanner(System.in);
		//System.out.println("Ingrese el numero de filas");
		//String entrada = teclado.nextLine();
		//int filas=Integer.parseInt(entrada);
		//int columnas=Integer.parseInt(entrada);
		//System.out.println("Ingrese la matriz del grafo en el formato del enunciado y presionar enter");
		
		
		
		
		
		
	}}
		
		
	

	
