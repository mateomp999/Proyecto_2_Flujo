package Proyecto2_FLujo;

public class Organizacion {
	
	String[][] sillas;
	String[][] pasajeros;
	//la asignacion final del avion
	String[] avionFinal;
	//Grafo
	int[][] matriz;
	//alas
	double balanceHorizontal=0;
	//largo
	double balanceVertical=0;
	String[][] grupo;
	Boolean[] compro;
	int sumH=0;
	int sumV=0;
	
	public Organizacion(String[][] sillas, String[][] pasajeros, String vueloId)
	{
		this.sillas=sillas;
		this.pasajeros=pasajeros;
		this.matriz=new int[sillas.length+3][sillas.length+3];
		this.avionFinal= new String[sillas.length];
		this.crearMatriz();
		compro=new Boolean[sillas.length];
		for(int i=0;i<sillas.length;i++)
		{
			compro[i]=false;
		}
		
		//toca filtrar por mismo vuelo
		for(int i=0;i<pasajeros.length;i++)
		{
			if(Double.parseDouble(pasajeros[i][4])==Double.parseDouble(vueloId))
			{
				int numeroSilla=encontrarSilla(pasajeros[i][2]);
				
				if(numeroSilla!=188)
				{
					if(!pasajeros[i][7].equals("NULL"))
					{
												
						int a=sillas.length;
						if(sillas[numeroSilla][1].equals("0.0"))
						{
							matriz[sillas.length][numeroSilla]=-1;
						}
						else if(sillas[numeroSilla][1].equals("1.0"))
						{
							matriz[sillas.length+1][numeroSilla]=-1;
						}
						else if(sillas[numeroSilla][1].equals("2.0"))
						{
							matriz[sillas.length+2][numeroSilla]=-1;
						}
						
						balanceHorizontal+=Double.parseDouble(sillas[numeroSilla][4]);
						balanceVertical+=Double.parseDouble(sillas[numeroSilla][3]);
						avionFinal[numeroSilla]=pasajeros[i][1];
						compro[numeroSilla]=true;
					}
					else
					{
						if(i<54882)
						{
							if(pasajeros[i][0].equals(pasajeros[i+1][0]))
							{
								int k=i;
								int j=0;
								grupo=new String[sillas.length][pasajeros[0].length];
								grupo[j]=pasajeros[k];
								j++;
								k++;
								boolean ultimo =false;
								
									while(pasajeros[k][0].equals(pasajeros[k+1][0])&&!ultimo)
									{
										if(k==54881)
										{ultimo=true;}
										grupo[j]=pasajeros[k];
										j++;
										k++;
										if(k==54882)
										{k=54881;}
										
										
										
									}
									if(k==54881) {k++;}
									grupo[j]=pasajeros[k];
									i=k;
								
								
								
								this.asignarGrupo(grupo,j+1);
								
							}
							else
							{
								this.asignar(pasajeros[i]);
							}
						}
						
						
					}
				}
				
			}
			}
		
		for(int i=0;i<sillas.length;i++)
		{
			String[] actual=sillas[i];
			if(avionFinal[i]!=null)
			{
				sumH+=Double.parseDouble(sillas[i][4]);
				sumV+=Double.parseDouble(sillas[i][3]);
			}
			
		}
		int a=0;
			
	}
	
	public String[] getAvion()
	{
		return avionFinal;
	}
	
	public double getSumV() {
		return sumV;
	}
	
	public double getSumH() {
		return sumH;
	}
	
	public Boolean[] getComprados() {
		return compro;
	}

	//crear grafo con sillas y con nodos clases (3).
	//orden sillas;
	//son 6 letras por cada fila
	public void crearMatriz() {
		int lon1=sillas.length;
		//inicio
		for(int j=0;j<sillas.length+3;j++)
		{
			for(int i=0;i<sillas.length+3;i++)
			{
				if(i==j)
				{
					matriz[i][j]=0;
				}
				else
				{
					matriz[i][j]=-1;
				}
				
			}
		}
		
		
		//asignar los los niveles a 
		for(int j=0;j<sillas.length;j++)
		{
			
			int a=sillas.length;
			int b=matriz.length;
			
				if(sillas[j][1].equals("0.0"))
				{
					matriz[sillas.length][j]=1;
				}
				else if(sillas[j][1].equals("1.0"))
				{
					matriz[sillas.length+1][j]=1;
				}
				else if(sillas[j][1].equals("2.0"))
				{
					matriz[sillas.length+2][j]=1;
				}	
					
				
		}
	}
	
	public void asignarGrupo(String[][] grupo, int num)
	{
		int[] asignacion= new int[num];
		for(int m=0;m<num;m++)
		{
			int[][] matrizNueva= new int[sillas.length+4][sillas.length+4];
			
			for(int j=0;j<sillas.length+3;j++)
			{
				for(int i=0;i<sillas.length+3;i++)
				{
					matrizNueva[i][j]=matriz[i][j];
				}
				
			}
			
			
			for(int i=0;i<matrizNueva.length-4;i++)
			{
				
				matrizNueva[sillas.length+3][i]=-1;
			}
			
			matrizNueva[sillas.length+3][sillas.length]=1;
			matrizNueva[sillas.length+3][sillas.length+1]=3;
			matrizNueva[sillas.length+3][sillas.length+2]=2;
			matrizNueva[sillas.length+3][sillas.length+3]=0;
			
			
			
			
			for(int i=0;i<asignacion.length;i++)
			{
				if(asignacion[i]!=0)
				{
					int fila=filaMatrizPorNivel(asignacion[i]);
					for(int j=-40;j<40;j++)
					{
						if(asignacion[i]+j>=0&&asignacion[i]+j<=sillas.length)
						{
							if(matrizNueva[fila][asignacion[i]+j]!=-1&&matrizNueva[fila][asignacion[i]+j]!=0)
							{
								matrizNueva[fila][asignacion[i]+j]+=1;
							}
						}
						
					}
					
				}
			}
			
			Bellman respuesta=new Bellman(matrizNueva, sillas.length+3);
			Integer[][] respuesta2=respuesta.resolver();
			
			int distMin=99999999;
			int indiceMin=-1;
			
			for(int k=0;k<matriz.length-4;k++)
			{
				if(respuesta2[(sillas.length+3)*2][k]<distMin)
				{
					distMin=respuesta2[(sillas.length+3)*2][k];
					indiceMin=k;
				}
			}
			
			balanceHorizontal+=Double.parseDouble(sillas[indiceMin][4]);
			balanceVertical+=Double.parseDouble(sillas[indiceMin][3]);
			asignacion[m]=indiceMin;
			avionFinal[indiceMin]=grupo[m][1];
			int fila=filaMatrizPorNivel(indiceMin);
			matriz[fila][indiceMin]=-1;
			
		}
		
		int a=0;
		
	}

	public void asignar(String[] pasajero) {
		
		int[][] matrizNueva= new int[sillas.length+4][sillas.length+4];
		
		for(int j=0;j<sillas.length+3;j++)
		{
			for(int i=0;i<sillas.length+3;i++)
			{
				matrizNueva[i][j]=matriz[i][j];
			}
			
		}
		
		for(int i=0;i<matrizNueva.length-4;i++)
		{
			matrizNueva[sillas.length+3][i]=-1;
		}
		
		//controlar balance
		for(int i=0;i<sillas.length;i++)
		{
			int fila=filaMatrizPorNivel(i);
			if(matrizNueva[fila][i]!=-1&&matrizNueva[fila][i]!=0)
			{
				if(balanceHorizontal>0)
				{
					if(Double.parseDouble(sillas[i][4])==1)
					{
						matrizNueva[fila][i]+=1;
					}
					else if(Double.parseDouble(sillas[i][4])==2)
					{
						matrizNueva[fila][i]+=2;
					}
					else if(Double.parseDouble(sillas[i][4])==3)
					{
						matrizNueva[fila][i]+=3;
					}
					
					
				}
				else if(balanceHorizontal<0)
				{
					if(Double.parseDouble(sillas[i][4])==-1)
					{
						matrizNueva[fila][i]+=1;
					}
					else if(Double.parseDouble(sillas[i][4])==-2)
					{
						matrizNueva[fila][i]+=2;
					}
					else if(Double.parseDouble(sillas[i][4])==-3)
					{
						matrizNueva[fila][i]+=3;
					}
					
				}
				
				if(balanceVertical>0)
				{
					if(Double.parseDouble(sillas[i][3])==1)
					{
						matrizNueva[fila][i]+=1;
					}
					
					
				}
				else if(balanceVertical<0)
				{
					if(Double.parseDouble(sillas[i][3])==-1)
					{
						matrizNueva[fila][i]+=1;
					}
					else if(Double.parseDouble(sillas[i][3])==-1.125)
					{
						matrizNueva[fila][i]+=1.125;
					}
					
					
				}
			}
			
		}
		
			
			
			
		matrizNueva[sillas.length+3][sillas.length]=1;
		matrizNueva[sillas.length+3][sillas.length+1]=3;
		matrizNueva[sillas.length+3][sillas.length+2]=2;
		matrizNueva[sillas.length+3][sillas.length+3]=0;
		
		Bellman respuesta=new Bellman(matrizNueva, sillas.length+3);
		Integer[][] respuesta2=respuesta.resolver();
		
		int distMin=99999999;
		int indiceMin=-1;
		
		for(int k=0;k<matriz.length-4;k++)
		{
			if(respuesta2[(sillas.length+3)*2][k]<distMin)
			{
				distMin=respuesta2[(sillas.length+3)*2][k];
				indiceMin=k;
			}
		}
		
		balanceHorizontal+=Double.parseDouble(sillas[indiceMin][4]);
		balanceVertical+=Double.parseDouble(sillas[indiceMin][3]);
		avionFinal[indiceMin]=pasajero[1];
		int fila=filaMatrizPorNivel(indiceMin);
		matriz[fila][indiceMin]=-1;
		
		int a =0;
				
		
	}
	
	
	//encuentra la posicion de la silla en la martriz
	public int encontrarSilla(String pasajeros)
	{
		String[] posicion=pasajeros.split("");
		int numeroSilla;
		int numeroFila;
		
		if(posicion.length==2) 
		{
			numeroFila=Integer.parseInt(posicion[0]);
			if(posicion[1].equals("A"))
			{
				numeroSilla=(numeroFila-1)*6+0;
			}
			else if(posicion[1].equals("B"))
			{
				numeroSilla=(numeroFila-1)*6+1;
			}
			else if(posicion[1].equals("C"))
			{
				numeroSilla=(numeroFila-1)*6+2;
			}
			else if(posicion[1].equals("D"))
			{
				numeroSilla=(numeroFila-1)*6+3;
			}
			else if(posicion[1].equals("E"))
			{
				numeroSilla=(numeroFila-1)*6+4;
			}
			else
			{
				numeroSilla=(numeroFila-1)*6+5;
			}
		}
		else
		{
			numeroFila=Integer.parseInt(posicion[0]+posicion[1]);
			if(posicion[2].equals("A"))
			{
				numeroSilla=(numeroFila-1)*6+0;
			}
			else if(posicion[2].equals("B"))
			{
				numeroSilla=(numeroFila-1)*6+1;
			}
			else if(posicion[2].equals("C"))
			{
				numeroSilla=(numeroFila-1)*6+2;
			}
			else if(posicion[2].equals("D"))
			{
				numeroSilla=(numeroFila-1)*6+3;
			}
			else if(posicion[2].equals("E"))
			{
				numeroSilla=(numeroFila-1)*6+4;
			}
			else
			{
				numeroSilla=(numeroFila-1)*6+5;
			}
		}
		
		
		
		return numeroSilla;
	}
	
	public int filaMatrizPorNivel(int j)
	{
		
		if(sillas[j][1].equals("0.0"))
		{
			return sillas.length;
		}
		else if(sillas[j][1].equals("1.0"))
		{
			return sillas.length+1;
		}
		else if(sillas[j][1].equals("2.0"))
		{
			return sillas.length+2;
		}
		
		return -1;
		
	}
	
}
