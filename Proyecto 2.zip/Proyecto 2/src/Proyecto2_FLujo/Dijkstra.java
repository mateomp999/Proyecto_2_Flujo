package Proyecto2_FLujo;

public class Dijkstra {
	
	int[][] matriz;
	int i;
	
	public Dijkstra(int[][] matrizNueva, int i) {
		
		this.matriz=matrizNueva;
		this.i=i;
		
		
	}
	
	public Integer[][] resolver()
	{
		//cada nodo tendra tres filas. la primera es de distancias,
		//la segunda de predecesores y la tercera de nodos visitados
		Integer[][] respuesta= new Integer[3*matriz.length][matriz.length];
		
		
			 
			for(int j=0;j<matriz.length;j++)
			{
				// llenar distancias
				respuesta[i*3][j]=9999999;
				// llenar lista de nodos no visitados
				respuesta[i*3+2][j]=1;
			}
			
			//primer nodo
			respuesta[i*3][i]=0;
			respuesta[i*3+1][i]=0;
			//*sacar de la lista de nodos a i
			respuesta[i*3+2][i]=0;
			
			for(int j=0;j<matriz.length;j++)
			{
				if(matriz[i][j]!=-1&&matriz[i][j]!=0)
				{
					if(respuesta[i*3][j]>respuesta[i*3][i]+matriz[i][j])
					{
						respuesta[i*3][j]=respuesta[i*3][i]+matriz[i][j];
						respuesta[i*3+1][j]=i+1;
						
					}
				}
			}
			
			//el resto de los nodos
			for(int j=0;j<matriz.length-1;j++)
			{
				int distMin=99999999;
				int indiceMin=-1;
				
				for(int k=0;k<matriz.length;k++)
				{
					if(respuesta[i*3][k]<distMin && respuesta[i*3+2][k]!=0)
					{
						distMin=respuesta[i*3][k];
						indiceMin=k;
					}
				}
				
				
				for(int k=0;k<matriz.length;k++)
				{					
					if(matriz[indiceMin][k]!=-1&&matriz[indiceMin][k]!=0)
					{
						if(respuesta[i*3][k]>respuesta[i*3][indiceMin]+matriz[indiceMin][k])
						{
							respuesta[i*3][k]=respuesta[i*3][indiceMin]+matriz[indiceMin][k];
							respuesta[i*3+1][k]=indiceMin+1;
							
						}
					}
				}
				
				respuesta[i*3+2][indiceMin]=0;				
				
			}
			
			Integer[][] respuesta2= new Integer[2][matriz.length];
			
			for(int k=0;k<2;k++)
			{
				for(int j=0;j<matriz.length;j++)
				{
					respuesta2[k][j]=respuesta[i*3+k][j];
				}
			}
		
		return respuesta2;
	}

}
