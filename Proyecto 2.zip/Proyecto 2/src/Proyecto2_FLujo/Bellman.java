package Proyecto2_FLujo;

public class Bellman {

	int[][] matriz;
	int i;
	
	
	public Bellman(int[][] matrizNueva,int i) {
		
		this.matriz=matrizNueva;
		this.i=i;
		
	}
	
	public Integer[][] resolver()
	{
		//cada nodo tendra tres filas. la primera es de distancias,
		//la segunda de predecesores y la tercera de nodos visitados
		Integer[][] respuesta= new Integer[2*matriz.length][matriz.length];
		
		//for(int i=0; i<matriz.length;i++)
		//{
		
			for(int j=0;j<matriz.length;j++)
			{
				respuesta[i*2][j]=9999999;
			}
			
			respuesta[i*2][i]=0;
			respuesta[i*2+1][i]=0;
			
			for(int j=0;j<matriz.length;j++)
			{
				for(int k=0;k<matriz.length;k++)
				{
					int a=matriz[j][k];
					int b=respuesta[i*2][j];
					int c=respuesta[i*2][k];
					if(matriz[j][k]!=0&&matriz[j][k]!=-1) {
						if(matriz[j][k]+respuesta[i*2][j]<respuesta[i*2][k])
						{
							respuesta[i*2][k]=matriz[j][k]+respuesta[i*2][j];
							respuesta[i*2+1][k]=j+1;
						}
					}
					
				}
			}
			
		//}
		
		return respuesta;
	}
}
